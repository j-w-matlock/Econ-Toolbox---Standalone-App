using System.Windows;

namespace EconToolbox.Desktop
{
    public partial class App : Application
    {
    }
}
